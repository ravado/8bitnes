</div><!-- main-container -->


<div id="footer">
    <div id="fixed-footer">
        <p>Emulroom © 2012 all rights reserved</p>
    </div>
</div>
<!-- close footer -->

<?php wp_footer(); ?>

</body>


</html>