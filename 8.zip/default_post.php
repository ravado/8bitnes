<!-- Шаблон для стандартного вывода записей -->
<div class="single-game complete-block">
    <div class="blue-head-block"><?php the_title() ?></div>
    <div class="block-content">
        <?php the_content(); ?>
    </div>
</div>